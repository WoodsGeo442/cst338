public interface Ability{
    
}