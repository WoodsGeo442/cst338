package Lab;

public interface ItemOne {
    public abstract void activate();

}
