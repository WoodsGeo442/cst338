package Lab;

public interface ItemTwo {
    public abstract void deactivate();
}
