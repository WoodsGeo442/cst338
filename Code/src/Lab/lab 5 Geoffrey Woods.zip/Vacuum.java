package Lab;

public abstract class Vacuum implements ItemOne, ItemTwo {
    boolean on;
    Vacuum(){
        on = false;
    }
}
