public interface IStone {

    public abstract void special(Person owner);
}
