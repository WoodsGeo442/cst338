public class Thanos extends Person {
    public Thanos(){
        super.setPower(100.0);
        super.setLocation("Titan");
        super.setName("Thanos");
    }
}
